class Global {
  static List<Map> game = [
    {
      "imeg": "https://i.ytimg.com/vi/d7rXG4u_4Kw/maxresdefault.jpg",
      "name": "Warhammer Aos:Realm War",
      "sname": "Compete in thrilling battles",
    },
    {
      "imeg":
          "https://www.howtogeek.com/wp-content/uploads/2021/03/roblox_hero_1.jpg?height=200p&trim=2,2,2,2&crop=16:9",
      "name": "ROBLOX",
      "sname": "Game over half of u.s. kids play",
    },
    {
      "imeg":
          "https://assets.nintendo.com/image/upload/c_fill,w_1200/q_auto:best/f_auto/dpr_2.0/ncom/en_US/games/switch/j/jumanji-the-video-game-switch/hero",
      "name": "JUMANJI",
      "sname": "The video game",
    },
  ];

  static List<Map> game1 = [
    {
      "imeg":
          "https://play-lh.googleusercontent.com/PHrDRhRQdJ2yhm57Yq_YDm5h2Fcp6jkK58JU4wNZf2qp0EKrm2B77olqNYN13rmcSMs",
      "name": "Kings of pool",
      "sname": "Ultimate Ar pool",
    },
    {
      "imeg":
          "https://play-lh.googleusercontent.com/VhwlwQOnf_lUrhCUoTcKP8O1dMecYxOhpa1FimQryAIL723NjAhzz0GeH7RB70GKgQ=w240-h480-rw",
      "name": "Shadow Fight 2",
      "sname": "NEKKI",
    },
    {
      "imeg":
          "https://freepngimg.com/thumb/call_of_duty/10-2-call-of-duty-png-pic-thumb.png",
      "name": "Call of Duty",
      "sname": "Activision publishing ",
    },
  ];

  static List<Map> app = [
    {
      "imeg":
          "https://www.how2shout.com/wp-content/uploads/2018/03/Know-Instagram-last-seen-Activity.jpg",
      "name": "Instagram ",
      "sname": "Instagram plus his/her last seen",
    },
    {
      "imeg":
          "https://i0.wp.com/vodapav.in/wp-content/uploads/2020/02/Snapchat-Find-a-Friend.jpg?fit=1200%2C630&ssl=1",
      "name": "Snapchat",
      "sname": "Find a Friend",
    },
    {
      "imeg":
          "https://static.jeffbullas.com/wp-content/uploads/2016/03/osting-a-Twitter-event.png",
      "name": "Twitter",
      "sname": "Hosting a twitter party",
    },
  ];

  static List<Map> app1 = [
    {
      "imeg": "https://1000logos.net/wp-content/uploads/2021/12/Byjus-Logo.png",
      "name": "BYJU'S",
      "sname": "the Learning App",
    },
    {
      "imeg":
          "https://play-lh.googleusercontent.com/qS_rE_kMQSEs_7ZZkzuZNUbRGxif7np1TxOJsv0lsnGKjFQ3cf1d6mp3BMKCcvxWCFY",
      "name": "Jio Mart",
      "sname": "Online Shopping App",
    },
    {
      "imeg":
          "https://play-lh.googleusercontent.com/4jlq9fgOmpkCikwBzJYkbXlkruFo1ygmaLaaLcLph9ln8sQgQ78P0-6teFkczp1S0N-l",
      "name": "DigiLocker",
      "sname": "National eGovernan..",
    },
  ];
}
